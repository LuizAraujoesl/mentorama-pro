package br.com.cadastroalunos.start;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StartApplicationTests {

	@Test
	void contextLoads() {
	}

}
