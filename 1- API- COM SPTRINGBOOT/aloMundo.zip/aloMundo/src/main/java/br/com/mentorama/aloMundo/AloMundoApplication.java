package br.com.mentorama.aloMundo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AloMundoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AloMundoApplication.class, args);
	}

}
