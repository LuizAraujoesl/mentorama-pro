package br.com.mentorama.aloMundo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AloMundoApplicationTests {

	@Test
	void contextLoads() {
	}

}
